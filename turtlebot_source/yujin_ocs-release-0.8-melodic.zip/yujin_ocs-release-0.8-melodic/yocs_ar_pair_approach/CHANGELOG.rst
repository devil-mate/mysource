^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package yocs_ar_pair_approach
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.6.3 (2014-12-05)
------------------

0.6.2 (2014-11-30)
------------------

0.6.1 (2014-07-08)
------------------
* queue_size updates
* apply install rules for new packages
* migrates ar marker based algorithms from kobuki x
* Contributors: Jihoon Lee
