Simple search behaviour.

Requires the ar_pair_tracking and kobuki nodes for working.