^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package yocs_waypoint_provider
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Forthcoming
* add missing install rules

0.6.2 (2014-11-30)
------------------
* update yaml cpp dependency `#63 <https://github.com/yujinrobot/yujin_ocs/issues/63>`_
* [yocs_waypoint_provider] : fix timestamping so rviz will always display
  them (http://wiki.ros.org/rviz/DisplayTypes/Marker)
* yocs_waypoint_provider: add handling of way point trajectories
* renames yocs_waypoint_manager to yocs_waypoint_provider (resolves `#46 <https://github.com/yujinrobot/yujin_ocs/issues/46>`_)
* Contributors: Daniel Stonier, Jihoon Lee, Marcus Liebhardt

0.6.1 (2014-07-08)
------------------
* updating package informations. remove email for authors. updating maintainer
* waypoint manager yaml compatibility fix
* update package info
* working version. marker appears properly.
* seems ready. markers does not appear in rviz though
* rename waypoints to waypoint
* Contributors: Jihoon Lee
