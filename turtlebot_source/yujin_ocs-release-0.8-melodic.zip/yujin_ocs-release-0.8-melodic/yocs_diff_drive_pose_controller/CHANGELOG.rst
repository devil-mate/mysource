^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package yocs_diff_drive_pose_controller
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.8.0 (2016-05-06)
------------------
* verbose option
* bugfix for wrapping angles properly

0.6.4 (2015-10-10)
------------------
* many minor improvements

0.6.0 (2014-07-08)
------------------
* updating package informations. remove email for authors. updating maintainer
* pose_controller: removes result feedback when tracking new pose
* pose_controller: improves pose approach
* pose_controller: adds limits for linear vel
* pose_controller: add goal reached logic and control
* remove unused parameters.
* Contributors: Daniel Stonier, Jihoon Lee, Marcus Liebhardt

0.5.3 (2014-03-24)
------------------

0.5.2 (2013-11-05)
------------------

0.5.1 (2013-10-14)
------------------

0.5.0 (2013-10-11)
------------------

0.4.1 (2013-10-08)
------------------

0.4.0 (2013-08-29)
------------------
* Add bugtracker and repo info URLs.
* Changelogs at package level.

0.3.0 (2013-07-02)
------------------
* Initial version.

0.2.3 (2013-04-15)
------------------

0.2.2 (2013-02-10)
------------------

0.2.1 (2013-02-08)
------------------

0.2.0 (2013-02-07)
------------------

0.1.3 (2013-01-08)
------------------

0.1.2 (2013-01-02)
------------------

0.1.1 (2012-12-21)
------------------

0.1.0 (2012-12-05)
------------------
