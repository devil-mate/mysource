^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package yocs_ar_pair_tracking
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.6.3 (2014-12-05)
------------------

0.6.2 (2014-11-30)
------------------
* update navigation configurations
* switch maintainer to jihoonl and add yaml-cpp dependency. Fix `#56 <https://github.com/yujinrobot/yujin_ocs/issues/56>`_
* reduce covariance size to fix `#53 <https://github.com/yujinrobot/yujin_ocs/issues/53>`_
* reduce covariance size to fix `#53 <https://github.com/yujinrobot/yujin_ocs/issues/53>`_
* add issue tracker and repository info
* Contributors: Jihoon Lee, dwlee

0.6.1 (2014-07-08)
------------------
* remove eclipse files from bad src location.
* apply install rules for new packages
* use ar_track_alvar_msgs instead of ar_track_alvar
* covariance matrix when it creates pose message closes `#34 <https://github.com/yujinrobot/yujin_ocs/issues/34>`_
* ar_pair_tracking system working
* migrates ar marker based algorithms from kobuki x
* Contributors: Daniel Stonier, Jihoon Lee, jihoonl
