=========
Changelog
=========

0.8.0 (2016-05-06)
------------------
* ecl deprecation macros
* pretty printing vectors updated

0.6.0 (2014-07-08)
------------------
* updating package informations. remove email for authors. updating maintainer
* Handle special case on sameFrame function
* Add functions to compare frame ids ignoring the leading /, as it is
  frequently omitted.
  Geometry doxygen documented.
* Contributors: Jihoon Lee, Jorge Santos

0.5.2 (2013-11-05)
------------------
* Some more functions added.

0.4.1 (2013-10-08)
------------------
* Initial version: migrated here from https://github.com/yujinrobot/kobuki-x

