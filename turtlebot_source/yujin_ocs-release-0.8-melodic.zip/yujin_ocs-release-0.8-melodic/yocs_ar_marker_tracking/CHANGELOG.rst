^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package yocs_ar_marker_tracking
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.6.3 (2014-12-05)
------------------
* Merge branch 'indigo-devel' into indigo
* Delete the duplicate package
* Contributors: DaikiMaekawa, Jihoon Lee

0.6.2 (2014-11-30)
------------------
* update yaml cpp dependency `#63 <https://github.com/yujinrobot/yujin_ocs/issues/63>`_
* tracked marker prints conf dist and conf head as well
* disable conf_heading. it does not work..
* updates
* add extra spotted and closest function
* Merge branch 'indigo' into indigo-devel
* switch maintainer to jihoonl and add yaml-cpp dependency. Fix `#56 <https://github.com/yujinrobot/yujin_ocs/issues/56>`_
* Add depend on yaml-cpp for yocs_ar_marker_tracking
* fix the yaml parser fix
* fix the yaml parser redfine bug
* Contributors: DongWook Lee, Jihoon Lee, Marcus Liebhardt, Scott K Logan

0.6.1 (2014-07-08)
------------------
* apply install rules for new packages
* use ar_track_alvar_msgs instead of ar_track_alvar
* remove eclipse files from bad src location.
* yaml 0.5 support
* ar_pair_tracking system working
* migrates ar marker based algorithms from kobuki x
* Contributors: Daniel Stonier, Jihoon Lee
