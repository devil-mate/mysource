^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package turtlebot_arm_moveit_config
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.3.3 (2014-09-20)
------------------

0.3.2 (2014-08-30)
------------------
* Add turtlebot_arm_moveit.launch: a version of demo.launch with simulation on/off

0.3.1 (2014-08-22)
------------------
* Set separated URLs for website, repository and bugtracker

0.3.0 (2014-08-16)
------------------
* First indigo release
