git add -A
git commit -am "$(date "+%Y-%m-%d %H:%M:%S")"
git push